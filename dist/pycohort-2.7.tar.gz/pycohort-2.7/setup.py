from setuptools import setup

setup(name='pycohort',
      version='2.7',
      description='pycohort package',
      url='https://github.com/demirkeseny',
      author='Yalim Demirkesen',
      author_email='yalimdemirkesen@gmail.com',
      license='MIT',
      packages=['pycohort'],
      zip_safe=False)