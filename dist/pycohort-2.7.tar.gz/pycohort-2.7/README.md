# pycohort

analyzing the retention rates